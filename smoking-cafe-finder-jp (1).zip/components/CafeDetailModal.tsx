
import React from 'react';

interface CafeDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  isFavorite: boolean;
  onToggleFavorite: () => void;
  cafe: {
    name: string;
    description: string;
    station?: string;
    address?: string;
    smokingType?: string;
    reliability?: string;
    notes?: string;
    mapUrl?: string;
  } | null;
}

export const CafeDetailModal: React.FC<CafeDetailModalProps> = ({ 
  isOpen, 
  onClose, 
  cafe,
  isFavorite,
  onToggleFavorite
}) => {
  if (!isOpen || !cafe) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
      <div 
        className="bg-white rounded-t-3xl sm:rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl animate-in slide-in-from-bottom-10 duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative p-6 pt-8 max-h-[90vh] overflow-y-auto">
          <div className="absolute top-4 right-4 flex gap-2 z-10">
            <button 
              onClick={onToggleFavorite}
              className={`p-2 rounded-full transition-all active:scale-125 ${isFavorite ? 'bg-red-50 text-red-500 shadow-sm' : 'bg-gray-100 text-gray-400'}`}
            >
              <svg 
                className={`w-6 h-6 ${isFavorite ? 'fill-current' : ''}`} 
                fill="none" 
                stroke="currentColor" 
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
            </button>
            <button 
              onClick={onClose}
              className="p-2 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors"
            >
              <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="mb-6">
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <span className="px-3 py-1 bg-orange-600 text-white text-[10px] font-black rounded-full uppercase tracking-wider">
                {cafe.smokingType}
              </span>
              {cafe.reliability && (
                <span className={`text-[10px] px-3 py-1 rounded-full font-bold ${
                  cafe.reliability.includes('高') ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                }`}>
                  信頼度: {cafe.reliability}
                </span>
              )}
            </div>
            <h2 className="text-2xl font-black text-gray-900 leading-tight pr-12">{cafe.name}</h2>
            <div className="flex flex-col gap-1 mt-2">
              {cafe.station && (
                <p className="text-sm text-gray-500 flex items-center gap-1 font-medium">
                  <span className="text-lg">🚉</span> {cafe.station}
                </p>
              )}
              {cafe.address && (
                <p className="text-sm text-gray-500 flex items-center gap-1 font-medium">
                  <span className="text-lg">📍</span> {cafe.address}
                </p>
              )}
            </div>
          </div>
          
          <div className="space-y-4 mb-8">
            <div className="bg-orange-50/50 rounded-2xl p-5 border border-orange-100">
              <h4 className="text-[10px] font-black text-orange-700 uppercase tracking-widest mb-2 flex items-center gap-1">
                <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" /><path fillRule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clipRule="evenodd" /></svg>
                喫煙情報の詳細
              </h4>
              <p className="text-gray-800 text-sm leading-relaxed whitespace-pre-wrap font-medium">
                {cafe.description}
              </p>
            </div>

            {cafe.notes && (
              <div className="bg-gray-50 rounded-2xl p-5 border border-gray-200">
                <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2 flex items-center gap-1">
                  <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" /></svg>
                  補足事項
                </h4>
                <p className="text-gray-600 text-sm leading-relaxed">
                  {cafe.notes}
                </p>
              </div>
            )}
          </div>

          <div className="flex flex-col gap-3">
            {cafe.mapUrl && (
              <a
                href={cafe.mapUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-3 w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-5 px-6 rounded-2xl transition-all shadow-xl shadow-blue-100 active:scale-[0.98]"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                </svg>
                Google マップを開く
              </a>
            )}
            <button
              onClick={onClose}
              className="w-full bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold py-5 px-6 rounded-2xl transition-colors active:scale-[0.98]"
            >
              閉じる
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
