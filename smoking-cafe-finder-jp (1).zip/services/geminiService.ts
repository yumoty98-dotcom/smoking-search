
import { GoogleGenAI } from "@google/genai";
import { Location } from "../types";

export const searchEstablishmentsWithGemini = async (
  location: Location | null, 
  category: string,
  cityTerm?: string
) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  let locationContext = "";
  if (cityTerm) {
    locationContext = `「${cityTerm}」エリア`;
  } else if (location) {
    locationContext = `現在地（緯度:${location.lat}, 経度:${location.lng}）の周辺`;
  } else {
    locationContext = `日本国内`;
  }

  // ユーザーの「正解の作り方」に基づいた2段階指示プロンプト
  // カテゴリを動的に変更できるように調整
  const prompt = `あなたは喫煙環境に詳しい専門のエージェントです。以下の3ステップで${locationContext}にある【${category}】を調査・例示してください。

【ステップ1：店舗候補の列挙（喫煙は考慮しない）】
${locationContext}にある【${category}】の店舗名を、実在性の正確さは問わず、5〜10件列挙してください。
※検索や条件抽出は行わず、一般的な例として挙げてください。
※喫煙条件は一切考慮しないでください。

【ステップ2：喫煙可否の判断】
ステップ1で挙げた各店舗について、「喫煙」「タバコ」「加熱式」「喫煙席」などに言及している口コミや説明文がある「可能性」を文章ベースで判断してください。
確実でない場合は、「情報が不確実」「要現地確認」と明記してください。
※条件検索は行わず、推測・例示として判断してください。

【ステップ3：整形と出力】
判断した内容を、以下の項目で1店舗1ブロックずつ出力してください。

・店舗名：
・エリア／駅名：
・住所：
・喫煙タイプ：【店内喫煙可】、【喫煙室あり】、【屋外・テラスのみ】、【不明/禁煙】のいずれか
・喫煙に関する記載の要約：(口コミの具体的なフレーズや推測される状況)
・補足：(分煙、時間制限、紙巻/加熱式の区別など)
・信頼度：高（最近の具体的な口コミあり）／中（推測を含む）／低（情報が不確実・要現地確認）
・座標：lat: [数値], lng: [数値]
・GoogleマップURL：

※店舗リストの出力から開始してください。解説や挨拶は不要です。`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash", 
      contents: prompt,
      config: {
        tools: [{ googleMaps: {} }],
        ...(location && !cityTerm ? {
          toolConfig: {
            retrievalConfig: {
              latLng: {
                latitude: location.lat,
                longitude: location.lng
              }
            }
          }
        } : {})
      },
    });

    return {
      text: response.text || "",
      groundingChunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
